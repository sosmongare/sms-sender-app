<?php

return [
    'api_key' => env('API_KEY'),
    'partner_id' => env('PARTNER_ID'),
    'shortcode' => env('SHORTCODE'),
];